package com.example.kallyruan.eldermap.NearbyLankmarkPkg;

public class Location {
    private Double latitude;
    private Double Longitude;

    Location(Double latitude, Double Longitude){
        this.latitude = latitude;
        this.Longitude = Longitude;
    }
}
